# 📊 Egyptian Stock Market Research Tool

> منصة بحث أكاديمية لجمع وتحليل بيانات سوق الأوراق المالية المصرية (EGX)

![Next.js](https://img.shields.io/badge/Next.js-15-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-CSS-38B2AC)
![License](https://img.shields.io/badge/License-MIT-green)

---

## 🌟 المميزات

- ✅ **202 شركة مصرية** مدرجة في البورصة المصرية
- ✅ **دعم اللغتين** العربية والإنجليزية (RTL/LTR)
- ✅ **18 قطاع اقتصادي** مختلف
- ✅ **مؤشرات اقتصادية كلية** (سعر الصرف، التضخم، الفائدة)
- ✅ **بيانات مالية شاملة** لكل شركة
- ✅ **بحث وفلترة متقدمة**
- ✅ **تصدير البيانات** إلى CSV

---

## 📋 المتغيرات المدعومة

### المتغيرات التابعة (Target Variables)
- الرسملة السوقية (Market Capitalization)
- سعر إغلاق السهم (Stock Closing Price)

### متغيرات هيكل التمويل (Capital Structure)
- نسبة المديونية إلى حقوق الملكية (Debt-to-Equity)
- إجمالي الديون (Total Debt)
- حقوق الملكية (Total Equity)

### متغيرات الأداء المالي (Financial Performance)
- العائد على الأصول (ROA)
- العائد على الملكية (ROE)
- ربحية السهم (EPS)
- نسبة السيولة (Current Ratio)

### البيانات البديلة (Alternative Data)
- مؤشر المشاعر (Sentiment Score)
- حجم التداول (Trading Volume)
- معدل التذبذب (Volatility)

### المتغيرات الاقتصادية الكلية (Macroeconomic)
- سعر صرف الدولار (USD/EGP)
- معدل التضخم (Inflation Rate)
- سعر الفائدة (Interest Rate)
- مؤشر EGX 30

---

## 🚀 التثبيت والتشغيل

### المتطلبات
- Node.js 18+
- npm أو bun

### خطوات التثبيت

```bash
# 1. استنساخ المشروع
git clone https://github.com/YOUR_USERNAME/egx-research-app.git
cd egx-research-app

# 2. تثبيت المتطلبات
npm install

# 3. إعداد قاعدة البيانات
npx prisma generate

# 4. تشغيل التطبيق
npm run dev
```

### فتح المتصفح
```
http://localhost:3000
```

---

## 📁 هيكل المشروع

```
egx-research-app/
├── src/
│   ├── app/
│   │   ├── page.tsx          # الصفحة الرئيسية
│   │   ├── layout.tsx        # Layout الرئيسي
│   │   └── api/              # API Routes
│   ├── components/
│   │   ├── ui/               # مكونات UI
│   │   ├── layout/           # Header, LanguageToggle
│   │   └── dashboard/        # بطاقات وجداول الشركات
│   ├── lib/
│   │   ├── egx-companies.ts  # قائمة الشركات المصرية
│   │   ├── translations.ts   # الترجمات
│   │   └── finance-api.ts    # تكامل Finance API
│   └── contexts/
│       └── LanguageContext.tsx
├── prisma/
│   └── schema.prisma         # قاعدة البيانات
└── package.json
```

---

## 🌐 النشر على Vercel

### الطريقة 1: من الموقع
1. اذهب إلى [vercel.com](https://vercel.com)
2. اربط حسابك بـ GitHub
3. اختر هذا المشروع
4. اضغط Deploy

### الطريقة 2: من CLI
```bash
npm install -g vercel
vercel login
vercel --prod
```

---

## 🛠️ التقنيات المستخدمة

| التقنية | الاستخدام |
|---------|----------|
| Next.js 15 | Framework |
| TypeScript | اللغة |
| Tailwind CSS | Styling |
| shadcn/ui | Components |
| Prisma | Database ORM |
| SQLite | Database |

---

## 📊 القطاعات المدعومة

| القطاع | عدد الشركات |
|--------|------------|
| البنوك | 12 |
| العقارات | 15 |
| الصناعات | 20 |
| الطاقة | 10 |
| المواد | 16 |
| السلع الاستهلاكية | 16 |
| الخدمات المالية | 18 |
| السياحة | 18 |
| التأمين | 10 |
| وغيرها... | |

---

## 📝 الترخيص

MIT License - راجع ملف [LICENSE](LICENSE) للتفاصيل.

---

## 👨‍💻 المساهمة

المساهمات مرحب بها! يرجى:
1. Fork المشروع
2. إنشاء Branch جديد
3. تقديم Pull Request

---

## 📞 التواصل

للاستفسارات والاقتراحات، يرجى فتح Issue جديد.

---

**تم التطوير لأغراض البحث الأكاديمي 🎓**
